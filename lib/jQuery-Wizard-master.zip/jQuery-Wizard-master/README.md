# jQuery plugin: Wizard

A simple plugin to convert a regular form into a wizard form.


### Install with Bower

```bash
$ bower install jquery-wizard-ByGiro --save
```

check the demo
